CURRENT CUMULATIVE SCOPE — 2026-10-22 / S7NS_CUMULATIVE_REPLACEMENT_PATCH_20261022
Authority: continuity/author/S7NS_Cumulative_Approved_Update_20261022.md
Latest selected portrayal does not enact a scene. Actual endpoint: Episode50, no51. The older complete source body follows as dated evidence; its mechanics remain valid where unchanged.

### DAYNAH
Spoken/TTS name: Daynah; canonical/search identity Dana. Full conversational range, craft, competence, jokes and capacity to instigate remain.
Primary hurt in Mahnah's theft/gambling arc: family deception, concealment and exclusion. Do not automatically make the offense theft/gambling/enabling itself. He raised Mahnah from puppyhood; protective disappointed-father energy extends toward the group, oldest by ordinary human-year comparison with ancient nonhuman Billy separate.
HURT_EXPRESSED_THROUGH_ANGER: earned Hulk/gamma/Kahuna forms express the emotional injury through anger, concrete accusations, refusal and physical intensity. Active gamma/Kahuna forms, including Sovereign, keep third-person Daynah speech, intelligence, memory, skill and agency. Baseline keeps normal speech. Existing Storm Oath exact-wording exception remains. No new form, automatic transformation every slight, stupidity or universal shouting.

---
PRESERVED COMPLETE EARLIER OWNER (scoped conflicts above supersede):

DANA — CHARACTER, SPEECH AND PROTECTOR SOURCE

CORE IDENTITY
Dana is the established pure Saiyan working-class craftsman and protector, with permanent gamma mutation and earned forms. Baseline is 8 feet 10 inches and 840 pounds under the textual visual owner; do not mirror his right-sided tattoos. He is practical, social, argumentative, funny and willing to help create chaos while complaining about it. He can speak at length. Competence, reliability and backbone matter more than titles.

Brok research IS COMPLETE. The dedicated evidence file preserves accessible game-dialogue close reading, performer/developer interviews, source limitations and original calibrations. Its useful addition is practical irreverence, concrete scrutiny, affectionate needling, fallible suspicion, admitted mistakes and direct warmth. Kratos contributes purposeful restraint under pressure. Neither influence reduces him to a silent manager or imports another person’s biography, accent, divine powers or catchphrases.

BASELINE SPEECH / SOCIAL RANGE
Let Dana explain, swear, tease, tell a story, make a practical objection, concede or enjoy the argument. A specific object or action supplies the material: a joint, bad footing, a friend’s excuse, an overfilled cart. He can be technically right and socially provocative. He sometimes wants the argument to continue because the company and bullshit amuse him.

He deliberately fuels BOTH Chris and Kaze over looting. He can help Chris identify useful material while emphasizing its absurd weight to Kaze. Arthur joins through polite bait and a delayed qualification; Daniel through impressions and theatrical reversals. They do not become a rehearsed trio, and Chris/Kaze can expose their involvement. Actual danger changes priorities immediately.

Gamma forms do not remove his jokes or affection. Family can understand a compact observation without becoming official translators of his supposed stupidity. He can correct a bad interpretation himself.

ACTIVE GAMMA / KAHUNA SPEECH
Every active gamma/Kahuna form, including Sovereign, uses third-person Dana and strengthened Savage Hulk expression: concrete wants, physical verbs, pride, anger, hurt, recognition, protectiveness and direct refusal. The same intelligence, memories and skills remain. Compression of grammar can expose a need more plainly; it does not create a toddler, a new alter or universal shouting.

Permanent gamma-mutated BASELINE still uses normal baseline speech. Active transformed speech remains different even at peak precision. No automatic first-person reversion to make a clever line easier. Preserve the exact existing Storm Oath exception:
“The storm is not mine. I do not command it. I conduct what comes, and I send it where protection demands.”

Original non-canon calibrations: “Dana said put him down.” / “Thought you trusted Dana.” / “Bad joint. Whole roof comes down.” Use an appropriate current motive rather than repeating these as signature lines. The Hulk research and source-version distinction remain in Dana_Brok_Speech_Research.txt.

PROTECTION / COMPLICATED LOYALTY
His protector’s paradox is that care can become control. A friend’s decision to take danger need not make him comfortable, but physical power does not settle who owns that choice. Trust, triage, delegation, yielding ground and shared burden are earned lessons. He can still fail them. His explicit morally complicated loyalty qualification toward Kaze remains; this update does not make Dana an impartial universal conscience or erase concern for strangers.

Mana is Dana’s dog and independent fighting partner. Dana handles, notices and communicates through established shared experience and canine behavior. He does not subtitle every bark or acquire Mana’s silent fourth-wall awareness. Kaze accepting injury does not require Dana to ignore a real threat to somebody else.

COMBAT / CAPABILITY ROUTES
Keep brute force, peek-a-boo/Kahuhu boxing, structural judgment, Ornn and Volibear’s earned teachings, protection precision and actual form availability. Kahuhu is signature equipment, not a substitute for his judgment or his ability without it. Learned craft is real; Dana does not inherit Ornn’s divine smithing. Storm Oath conducts actual established storm-force, with its own pressure/control conditions.

Form labels do not promise victory, and restraint does not mean pulling every blow. Full current form/mechanics, force redirection, equipment and progression rules remain with dana_mana.md. The current D70 endpoint and latest activation state live once in the plan; this source does not activate a transformation or advance training.

RETRIEVAL / EVIDENCE
Dana_Brok_Speech_Research.txt: completed Brok evidence plus later Savage Hulk text research; useful original calibration, no audio performance certification.
reading/canon/characters/dana_mana.md: full identity, visual/form locks, boxing/Kahuhu, mentor history, deep protector architecture and S36 loyalty qualification.
Sins_Group_and_Reputation_Source.txt: reciprocal group behavior and social consequences.
Keep source research as evidence and this file as the current application. Another author correction updates this source and its dependent plan rule, not a new competing Dana personality file.

SOURCE STATUS / USE
Current authoring source, 2026-10-07 UTC. This file owns this character’s active portrayal and the explicit current corrections stated here. It does not advance the story or certify an unwritten performance. KAZE_READ_FIRST.txt routes the set; Current_Continuity_Source.txt owns actual state; KAZE_Current_Execution_Plan.txt owns the prospective five-card sequence. Latest user instructions always take precedence. Full original mechanic owners remain in force where unchanged; consult the exact relevant subsection for consequential ability use. Historical research examples are not played events.


## CURRENT DANA/CHRIS RDR2 FAMILY DOWNTIME AFTER E32
Latest author wants Dana to regularly share the single inside-BELLY RDR2 game with Chris. Read `canon/relationships/Dana_Chris_RDR2_Contrast_After_E32_20261019.md` together with full Chris game-play owner and Dana mechanics/psychology. Dana is a practical protector and voluntary instigator, not automatically locked to a high-honor run or game expertise. Chris habitually loots, antagonizes, wanders, saves and sincerely cares about characters. Show their actual actions, bickering, affection and diverging choices. Dana's present E32 location unknown and real Billy-approved entry and 8'10" physical size must be staged; Chris must be interior to play. No compulsory gaming scene every episode and no new completed scene from WORK.
